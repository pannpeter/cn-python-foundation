
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)


"""
"There are <count> different telephone numbers in the records."
"""
telephones = []
for text in texts:
	telephones.append(text[0])
	telephones.append(text[1])
for call in calls:
	telephones.append(call[0])
	telephones.append(call[1])

telephoneSet = set(telephones)
print("There are {count} different telephone numbers in the records".format(count = len(telephoneSet)))