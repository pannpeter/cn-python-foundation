
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)


phone_last_times = {}

for call in calls:
    if(call[0] in phone_last_times):
        phone_last_times[call[0]] +=  int(call[3])
    else: 
        phone_last_times[call[0]] =  int(call[3])
    if(call[1] in phone_last_times):
        phone_last_times[call[1]] +=  int(call[3])
    else: 
        phone_last_times[call[1]] =  int(call[3])

longestTime = 0

for phone in phone_last_times:
    if(phone_last_times[phone] > longestTime):
        longestTime = phone_last_times[phone]

longestPhone = []
for phone in phone_last_times:
    if(phone_last_times[phone] == longestTime):
        longestPhone.append(phone)

print("{telephones} spent the longest time, {totaltimes} seconds, on the phone during".format(telephones = str(longestPhone),totaltimes=longestTime))
