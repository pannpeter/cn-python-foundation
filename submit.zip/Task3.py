
import csv

with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)


tele_called_byBanga = []

for call in calls:
    if("(080)" in call[0]):
        if("(0" in call[1]):           
            tele_called_byBanga.append(call[1][0:call[1].find(")")+1])
        elif(" " in call[1]):
            tele_called_byBanga.append(call[1][0:4])
        else:
            tele_called_byBanga.append("140")

telephones = set(tele_called_byBanga)
telephonesSorted = sorted(list(telephones))

print("The numbers called by people in Bangalore have codes:")
print("\n".join(telephonesSorted))

percent = 1.0*tele_called_byBanga.count('(080)')/len(tele_called_byBanga)


print("{:.2%} percent of calls from fixed lines in Bangalore are calls to other fixed lines in Bangalore.".format(percent))


