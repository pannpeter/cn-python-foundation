#-*- coding: UTF-8 -*- 

import expanddouban
from bs4 import BeautifulSoup
import csv
import codecs

"""
电影类，包括以下变量：
name = “肖申克的救赎” #电影名称
rate = 9.6 #电影评分
location = "美国" #电影类型
category = "剧情" #电影地区
info_link = "https://movie.douban.com/subject/1292052/" #电影页面链接
cover_link = “https://img3.doubanio.com/view/movie_poster_cover/lpst/public/p480747492.jpg” #电影海报图片链接
"""
class Movie:  
    name = "肖申克的救赎" #电影名称
    rate = 9.6 #电影评分
    location = "美国" #电影类型
    category = "剧情" #电影地区
    info_link = "https://movie.douban.com/subject/1292052/" #电影页面链接
    cover_link = "https://img3.doubanio.com/view/movie_poster_cover/lpst/public/p480747492.jpg" #电影海报图片链接
    #定义构造方法  
    def __init__(self,name,rate,location,category,info_link,cover_link):
        self.name = name
        self.rate = rate
        self.location = location
        self.category = category
        self.info_link = info_link
        self.cover_link = cover_link

"""
return a string corresponding to the URL of douban movie lists given category and location.
category: str, movie category, such as '剧情'
location: str, such as '美国'
"""
def getMovieUrl(category, location):   
    url = "https://movie.douban.com/tag/#/?sort=S&range=9,10&tags=电影"
    if category:
        url += "," + category 
    if location:
        url += "," + location
    return url
#for test
#print(getMovieUrl('剧情','香港'))

"""
return a list of Movie objects with the given category and location.
category: str, movie category, such as '剧情'
location: str, such as '美国'
"""
def getMovies(category, location):
    movies = []
    url = getMovieUrl(category,location)
    if not location:
        location = "全部地区"
    html = expanddouban.getHtml(url,True)
    soup = BeautifulSoup(html,'html.parser')
    wp_list = soup.find(class_="list-wp")
    for wp in wp_list.find_all("a", recursive=False):
        info_link,cover_link,name,rate = "","","",-1
        info_link = wp.get('href').encode("utf-8")
        #print(info_link)
        if wp.find(class_="pic"):
            cover_link = wp.find(class_="pic").img.get('src').encode("utf-8")
            #print(cover_link)
        if wp.find(class_="title"):
            name = wp.find(class_="title").get_text().encode("utf-8")
        if wp.find(class_="rate"):
            rate = wp.find(class_="rate").get_text().encode("utf-8")
        movie = Movie(name,rate,location,category,info_link,cover_link)
        movies.append(movie)
        #print(movie.name)
    return movies
#for test
#for movie in getMovies("剧情",""):
#    movieStr = "{},{},{},{},{},{}".format(movie.name,movie.rate,movie.category,movie.location,movie.info_link,movie.cover_link)
#    print(movieStr)

"""
write movie info into a csv file
movies: list of movie
"""
def writeCSV(movies):
    with open('movies.csv', 'w') as csvfile:    
        csvfile.write(codecs.BOM_UTF8)   
        writer = csv.writer(csvfile,dialect='excel')
        for movie in movies:
            writer.writerow([movie.name, movie.rate, movie.location, movie.category, movie.info_link, movie.cover_link])
"""
crawler 3 type movies of all areas from douban
"""
def doubancrawler():
    locations = ['大陆','美国','香港','台湾','日本','韩国','英国','法国','德国','意大利',
             '西班牙','印度','泰国','俄罗斯','伊朗','加拿大','澳大利亚','爱尔兰','瑞典','巴西','丹麦']
    categorys = ['剧情','喜剧','动作']
    movies = []
    for cat in categorys:
        for loc in locations:
            movies += getMovies(cat,loc)
    return movies

writeCSV(doubancrawler())

"""
get the movie count from every location
"""
def getlocationMovie():
    with open('movies.csv','r') as moviefile:
        reader = csv.reader(moviefile)
        movielist = list(reader)
        jq_movies,xj_movies,dz_movies = {},{},{}
        jqmoviecount,xjmoviecount,dzmoviecount = 0,0,0

        for movie in movielist:
            #print(movie)
            if movie[3] == '剧情':
                jqmoviecount += 1
                if movie[2] in jq_movies:
                    jq_movies[movie[2]] += 1
                else:
                    jq_movies[movie[2]] = 1
            elif movie[3] == '喜剧':
                xjmoviecount += 1
                if movie[2] in xj_movies:
                    xj_movies[movie[2]] += 1
                else:
                    xj_movies[movie[2]] = 1
            elif movie[3] == '动作':
                dzmoviecount += 1
                if movie[2] in dz_movies:
                    dz_movies[movie[2]] += 1
                else:
                    dz_movies[movie[2]] = 1
    return jq_movies,xj_movies,dz_movies

def getTop3(movieDict):
    countList = []
    for movie in movieDict:
        countList.append(movieDict[movie])          
    countList.sort()
    top3 = countList[-3:]
    top3Movies = {}
    print(top3)
    for movie in movieDict:
        if(movieDict[movie] in top3):
            top3Movies[movie] = [movieDict[movie], 1.0*movieDict[movie]/sum(countList)]
    return top3Movies
"""
write top3 locations into text file
"""
def writeTxt():
    JQ,XJ,DZ = getlocationMovie()
    with open('output.txt', 'w') as txtfile:    
        top3JQ = getTop3(JQ)
        top3XJ = getTop3(XJ)
        top3DZ = getTop3(DZ)
        txtfile.write("剧情类高分电影排名前3的地区：\r\n")
        for movie in top3JQ:
            txtfile.write("地区:{},数量:{},百分比:{:.2%}\r\n".format(movie,top3JQ[movie][0],top3JQ[movie][1]))
        txtfile.write("\r\n喜剧类高分电影排名前3的地区：\r\n")
        for movie in top3XJ:
            txtfile.write("地区:{},数量:{},百分比:{:.2%}\r\n".format(movie,top3XJ[movie][0],top3XJ[movie][1]))
        txtfile.write("\r\n动作类高分电影排名前3的地区：\r\n")
        for movie in top3DZ:
            txtfile.write("地区:{},数量:{},百分比:{:.2%}\r\n".format(movie,top3DZ[movie][0],top3DZ[movie][1]))

writeTxt()